export interface Location {
  lat: number;
  lng: number;
}
