export interface OperatorDto {
  id?: number,
  operatorName: string,
}
